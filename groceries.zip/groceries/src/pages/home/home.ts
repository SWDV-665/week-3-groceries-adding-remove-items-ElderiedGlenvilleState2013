import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  title = "Grocery";

  items = [
    {
      name: "Milk",
      quantity: 2
    },
    {
      name: "Bread",
      quantity: 1
    },
    {
      name: "Banana",
      quantity: 3
    },
    {
      name: "Sugar",
      quantity: 1
    }
  ];

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public alertCtrl: AlertController) {

  }
//function to remove items
  removeItem(item) {
    console.log("Removing items ");
    this.items.pop();
    const toast = this.toastCtrl.create({
      message: 'item was removed ' + item,
      duration: 3000
    });
    toast.present();
  }

  //function to add items into items array
  addItem() {
    console.log("adding items " );
    this.showAddItemPrompt();
  }

  //prompts alert prompt
  showAddItemPrompt() {
    const prompt = this.alertCtrl.create({
      title: 'Add Items',
      message: "Enter a name of items to add",
      inputs: [
        {
          name: 'name',
          placeholder: 'name'
        },
        {
          name: 'quantity',
          placeholder: 'quantity'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Save',
          handler: data => {
            console.log('Saved clicked');
            this.items.push(data);
          }
        }
      ]
    });
    prompt.present();
  }
}


